export const _SERVER_URI='https://app.oplus.dev'
export const _TOKEN = "4|eJ1so9HdGTHPOzYkso2TBb04B1YxJNl294zHyIzFb446e2e9";